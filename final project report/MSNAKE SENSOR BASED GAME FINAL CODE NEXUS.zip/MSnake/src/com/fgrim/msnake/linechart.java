package com.fgrim.msnake;

import java.util.ArrayList;
import java.util.List;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;



import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;

public class linechart extends Activity {
	List<Integer> graph = new ArrayList<Integer>();
	private String[] time = new String[] { "10AM", "12PM", "3PM", "6PM",
			"10PM", "1AM", };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.linechart);

		Spinner linechart_spinner = (Spinner) findViewById(R.id.spin_graph);
		
		openchart();
		
	}
		
		
		
		private void openchart() {
			
			 int[] x = { 1,2,3,4,5}; 
			 int[] left = {16,3,12,7,23};
			
			 int[] right = {2,2,4,5,1};
			 int[] top =
			  {5,19,21,5,4};
			 int[] bottom =
				  {7,20,14,7,6};
			 
			// public static ArrayList<Integer> x[] = new ArrayList<Integer>();
	/*
			ArrayList<Integer> x = new ArrayList<Integer>();
			x.add(1);
			x.add(2);
			x.add(3);
			x.add(4);
			x.add(5);*/
			// x.add(6);
			// x.add(7);
			// x.add(8);
			// x.add(9);

			//ArrayList<Integer> left = new ArrayList<Integer>();
			//left = TestGesture.leftge;
			//ArrayList<Integer> right = new ArrayList<Integer>();
			//right = TestGesture.rightge;
			//ArrayList<Integer> top = new ArrayList<Integer>();
			//top = TestGesture.topge;

			// left=TestGesture.leftge;
			// Creating an XYSeries for Income
			XYSeries leftSeries = new XYSeries("Left Gesture");
			// Creating an XYSeries for Income
			XYSeries rightSeries = new XYSeries("Right Gesture");

			// Creating an XYSeries for fun
			XYSeries topSeries = new XYSeries("Top Gesture");
			// Creating an XYSeries for fun
					XYSeries bottomSeries = new XYSeries("bottom Gesture");
			// Adding data to Income and Expense Series
			for (int i = 0; i < x.length; i++) {

				leftSeries.add(x[i], left[i]);
				// leftSeries.add(x, left);
				rightSeries.add(x[i], right[i]);
				topSeries.add(x[i], top[i]);
				bottomSeries.add(x[i], bottom[i]);
			}

			// Creating a dataset to hold each series
			XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
			// Adding Income Series to the dataset
			dataset.addSeries(leftSeries);
			// Adding Expense Series to dataset
			dataset.addSeries(rightSeries);
			dataset.addSeries(topSeries);
			dataset.addSeries(bottomSeries);

			// Creating XYSeriesRenderer to customize incomeSeries
			XYSeriesRenderer leftRenderer = new XYSeriesRenderer();
			leftRenderer.setColor(Color.YELLOW);
			leftRenderer.setPointStyle(PointStyle.SQUARE);
			leftRenderer.setFillPoints(true);
			leftRenderer.setLineWidth(2);
			leftRenderer.setDisplayChartValues(true);

			// Creating XYSeriesRenderer to customize expenseSeries
			XYSeriesRenderer rightRenderer = new XYSeriesRenderer();
			rightRenderer.setColor(Color.GREEN);
			rightRenderer.setPointStyle(PointStyle.SQUARE);
			rightRenderer.setFillPoints(true);
			rightRenderer.setLineWidth(3);
			rightRenderer.setDisplayChartValues(true);

			// Creating XYSeriesRenderer to customize incomeSeries
			XYSeriesRenderer topRenderer = new XYSeriesRenderer();
			topRenderer.setColor(Color.CYAN);
			topRenderer.setPointStyle(PointStyle.SQUARE);
			topRenderer.setFillPoints(true);
			topRenderer.setLineWidth(4);
			topRenderer.setDisplayChartValues(true);
			// Creating XYSeriesRenderer to customize incomeSeries
					XYSeriesRenderer bottomRenderer = new XYSeriesRenderer();
					topRenderer.setColor(Color.WHITE);
					topRenderer.setPointStyle(PointStyle.SQUARE);
					topRenderer.setFillPoints(true);
					topRenderer.setLineWidth(4);
					topRenderer.setDisplayChartValues(true);

			// Creating a XYMultipleSeriesRenderer to customize the whole chart
			XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
			multiRenderer.setXLabels(0);
			multiRenderer.setChartTitle("Comparison between different gestures");
			multiRenderer.setXTitle("Time");
			multiRenderer.setYTitle("Count");
			multiRenderer.setZoomButtonsVisible(true);
			for (int i = 0; i < x.length; i++) {
				multiRenderer.addXTextLabel(i + 1, time[i]);
			}

			// Adding incomeRenderer and expenseRenderer to multipleRenderer
			// Note: The order of adding dataseries to dataset and renderers to
			// multipleRenderer
			// should be same
			multiRenderer.addSeriesRenderer(leftRenderer);
			multiRenderer.addSeriesRenderer(rightRenderer);
			multiRenderer.addSeriesRenderer(topRenderer);
			multiRenderer.addSeriesRenderer(bottomRenderer);

			// Creating an intent to plot line chart using dataset and
			// multipleRenderer
			Intent intent = ChartFactory.getLineChartIntent(getBaseContext(),
					dataset, multiRenderer);

			// Start Activity
			startActivity(intent);

			}

			

}