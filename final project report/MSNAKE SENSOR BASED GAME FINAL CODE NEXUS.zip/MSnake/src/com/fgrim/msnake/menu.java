package com.fgrim.msnake;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class menu extends Activity implements OnClickListener
{
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		
		Button bNewGame = (Button) findViewById(R.id.button1);
		Button bPiechart = (Button) findViewById(R.id.button2);
		Button blinechart = (Button) findViewById(R.id.button3);
		Button bAnalysis = (Button) findViewById(R.id.button4);
		
		bNewGame.setOnClickListener(this);
		bPiechart.setOnClickListener(this);
		blinechart.setOnClickListener(this);
		bAnalysis.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.button1:
			Intent game = new Intent(menu.this, MSnake.class);
			startActivity(game);
			break;
		case R.id.button2:
			Intent piechart = new Intent(menu.this, charts.class);
			startActivity(piechart);
			break;
		case R.id.button3:
			Intent chart = new Intent(menu.this, linechart.class);
			startActivity(chart);
			break;
		case R.id.button4:
			Intent analysis = new Intent(menu.this, analysis.class);
			startActivity(analysis);
			break;
		}
		
		
	}
}

