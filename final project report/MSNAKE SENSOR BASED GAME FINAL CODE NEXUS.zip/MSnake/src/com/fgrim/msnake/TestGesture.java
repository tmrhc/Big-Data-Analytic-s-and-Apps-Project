 package com.fgrim.msnake; 
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import be.ac.ulg.montefiore.run.jahmm.Hmm;
import be.ac.ulg.montefiore.run.jahmm.ObservationVector;
import be.ac.ulg.montefiore.run.jahmm.OpdfMultiGaussianFactory;
import be.ac.ulg.montefiore.run.jahmm.io.ObservationSequencesReader;
import be.ac.ulg.montefiore.run.jahmm.io.ObservationVectorReader;
import be.ac.ulg.montefiore.run.jahmm.learn.BaumWelchLearner;
import be.ac.ulg.montefiore.run.jahmm.learn.KMeansLearner;
  
public class TestGesture {
	OpdfMultiGaussianFactory initFactoryPunch=null;
	Reader learnReaderPunch=null;
	List<List<ObservationVector>> learnSequencesPunch=null;
	KMeansLearner<ObservationVector> kMeansLearnerPunch=null;
	Hmm<ObservationVector> initHmmPunch=null;
	Hmm<ObservationVector> learntHmmPunch=null;
	Hmm<ObservationVector> learntHmmScrolldown=null;
	Hmm<ObservationVector> learntHmmSend=null;
	Hmm<ObservationVector> learntHmmdown=null;
	//Declaration of variables
	public static ArrayList<String> timeLine = new ArrayList<String>();
	public static int leftValue=0,rightValue=0,topValue=0, bottomValue=0;
	public static String dateValue="";
	public static ArrayList<Integer> leftgCount = new ArrayList<Integer>();
	public static ArrayList<Integer> rightgCount = new ArrayList<Integer>();
	public static ArrayList<Integer> topgCount = new ArrayList<Integer>();
	public static ArrayList<Integer> bottomgCount = new ArrayList<Integer>();
	String list_msg;
	 String root = Environment.getExternalStorageDirectory().toString();
	    File myDir = new File("/mnt/sdcard/Data/"); 
	    int x;
	    int x1;
	    int x2;
	    int x3;
	   
public void	train() {
	 myDir.mkdirs();
	// Create HMM for punch gesture
	Boolean exception =false;
	int x=10;
	 File fil = null;
	 
	while(!exception){
	try{
    OpdfMultiGaussianFactory initFactoryPunch = new OpdfMultiGaussianFactory(
            3);
    
    //File fil = new File (myDir, "punchlearn.seq");
    fil = new File("/mnt/sdcard/Data/gorightlatest.seq");
    System.out.println("file exits --> "+fil.exists());
    Reader learnReaderPunch = new FileReader(fil);
    List<List<ObservationVector>> learnSequencesPunch = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(), learnReaderPunch);
    learnReaderPunch.close();

    KMeansLearner<ObservationVector> kMeansLearnerPunch = new KMeansLearner<ObservationVector>(
            x, initFactoryPunch, learnSequencesPunch);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmPunch = kMeansLearnerPunch.iterate();
    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    
    BaumWelchLearner baumWelchLearnerPunch = new BaumWelchLearner();
     this.learntHmmPunch = baumWelchLearnerPunch.learn(
            initHmmPunch, learnSequencesPunch);
    exception=true;
    System.out.println(x);
	  }
	  catch(Exception e){
		  x--;
      System.out.println(x);
		  Log.i("scan", "train Exception 1");  
	  }

	}
	
	Log.i("scan", "train one completed");
    // Create HMM for scroll-down gesture
	Boolean exception1 =false;
	int x1=10;
	while(!exception1){
	File fil1 = null;
	try{
    OpdfMultiGaussianFactory initFactoryScrolldown = new OpdfMultiGaussianFactory(
            3);
    
    fil1 = new File("/mnt/sdcard/Data/goleftlatest.seq");
    System.out.println("file1 exits --> "+fil1.exists());
    

  //Reader learnReaderScrolldown = new FileReader(new File (myDir, "ltortrain.seq"));
    Reader learnReaderScrolldown = new FileReader(fil1);
    List<List<ObservationVector>> learnSequencesScrolldown = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(),
                    learnReaderScrolldown);
    learnReaderScrolldown.close();

    KMeansLearner<ObservationVector> kMeansLearnerScrolldown = new KMeansLearner<ObservationVector>(
            x1, initFactoryScrolldown, learnSequencesScrolldown);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmScrolldown = kMeansLearnerScrolldown
            .iterate();

    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    BaumWelchLearner baumWelchLearnerScrolldown = new BaumWelchLearner();
     this.learntHmmScrolldown = baumWelchLearnerScrolldown
            .learn(initHmmScrolldown, learnSequencesScrolldown);
     exception1=true;
     //System.out.println("here1");
     System.out.println(x1);
	  }
	  catch(Exception e){
		  x1--;
		 System.out.println(x1);
		  
	  }
	}
	
	Log.i("scan", "train two completed");
    // Create HMM for send gesture
	Boolean exception2 =false;
	int x2=10;
	File fil3 = null;
	while(!exception2){
	try{
    OpdfMultiGaussianFactory initFactorySend = new OpdfMultiGaussianFactory(
            3);
    
    fil3 = new File("/mnt/sdcard/Data/gouplatest.seq");
    System.out.println("File3 exits---->"+fil3.exists());
//    Reader learnReaderSend = new FileReader(new File (myDir, "rtoltrain.seq"));
    Reader learnReaderSend = new FileReader(fil3);
    List<List<ObservationVector>> learnSequencesSend = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(), learnReaderSend);
    learnReaderSend.close();

    KMeansLearner<ObservationVector> kMeansLearnerSend = new KMeansLearner<ObservationVector>(
            x2, initFactorySend, learnSequencesSend);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmSend = kMeansLearnerSend.iterate();

    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    BaumWelchLearner baumWelchLearnerSend = new BaumWelchLearner();
     this.learntHmmSend = baumWelchLearnerSend.learn(
            initHmmSend, learnSequencesSend);
     exception2=true;
     System.out.println(x2);
	  }
	  catch(Exception e){
		  x2--;
	System.out.println(x2);
		  
	  }
	}
	Log.i("scan", "train three completed");
	
	//create Hmm for down gesture
	
	Boolean exception3 =false;
	int x3=10;
	File fil4 = null;
	while(!exception3){
	try{
    OpdfMultiGaussianFactory initFactorydown = new OpdfMultiGaussianFactory(
            3);
    
    fil4 = new File("/mnt/sdcard/Data/gopunchlatest.seq");
    System.out.println("File4 exits---->"+fil4.exists());
//    Reader learnReaderSend = new FileReader(new File (myDir, "rtoltrain.seq"));
    Reader learnReaderdown = new FileReader(fil4);
    List<List<ObservationVector>> learnSequencesdown = ObservationSequencesReader
            .readSequences(new ObservationVectorReader(), learnReaderdown);
    learnReaderdown.close();

    KMeansLearner<ObservationVector> kMeansLearnerdown = new KMeansLearner<ObservationVector>(
            x3, initFactorydown, learnSequencesdown);
    // Create an estimation of the HMM (initHmm) using one iteration of the
    // k-Means algorithm
    Hmm<ObservationVector> initHmmdown = kMeansLearnerdown.iterate();

    // Use BaumWelchLearner to create the HMM (learntHmm) from initHmm
    BaumWelchLearner baumWelchLearnerdown = new BaumWelchLearner();
     this.learntHmmdown = baumWelchLearnerdown.learn(
            initHmmdown, learnSequencesdown);
     exception3=true;
     System.out.println(x3);
	  }
	  catch(Exception e){
		  x3--;
	System.out.println(x3);
		  
	  }
	}
	Log.i("scan", "train four completed");
}
	
    public String test(File seqfilename) throws Exception{
    	SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yy");
		Date date = new Date();
		dateValue=dateFormat.format(date);
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:MM:ss");
		Date date1 = new Date();
		String data = null;
        Reader testReader = new FileReader(seqfilename);
        List<List<ObservationVector>> testSequences = ObservationSequencesReader
                .readSequences(new ObservationVectorReader(), testReader);
        testReader.close();
        
        short gesture; // punch = 1, scrolldown = 2, send = 3
        double punchProbability, scrolldownProbability, sendProbability, downProbability;
        for (int i = 0; i < testSequences.size(); i++) {
       
            punchProbability = this.learntHmmPunch.probability(testSequences
                    .get(i));
            //System.out.println(this.learntHmmPunch.probability(testSequences.get(i)));
            gesture = 1;
            //System.out.println(this.learntHmmScrolldown);
            scrolldownProbability = this.learntHmmScrolldown.probability(testSequences
                    .get(i));
            
            if (scrolldownProbability > punchProbability) {
                gesture = 2;
            }
            sendProbability = this.learntHmmSend.probability(testSequences
                    .get(i));
            //System.out.println(punchProbability +","+scrolldownProbability +","+sendProbability);
             if ((gesture == 1 && sendProbability > punchProbability)
                    || (gesture == 2 && sendProbability > scrolldownProbability )) {
                gesture = 3;
            }
             downProbability = this.learntHmmdown.probability(testSequences.get(i));
             if ((gesture == 1 && downProbability > punchProbability)
                     || (gesture == 2 && downProbability > scrolldownProbability || (gesture==3 && downProbability > sendProbability) )) {
                 gesture = 4;
             }
            Log.i("probabilities", punchProbability + "   " + sendProbability  + "   " + scrolldownProbability +"  " + downProbability);
            System.out.println(gesture);
            if (gesture == 1) {
            	leftgCount.add(0);
				rightgCount.add(1);
				topgCount.add(0);
				bottomgCount.add(0);
				rightValue++;
            	System.out.println("This is a left gesture");
           
            	return "left";
            } else if (gesture == 2) {
            	leftgCount.add(1);
				rightgCount.add(0);
				topgCount.add(0);
				bottomgCount.add(0);
				leftValue++;
                System.out.println("This is a right gesture");                
            	return "right";
            } else if (gesture == 3) {
            	leftgCount.add(0);
				rightgCount.add(0);
				topgCount.add(1);
				bottomgCount.add(0);
				topValue++;
            	System.out.println("This is a up gesture");
            	
            	return "top";
            } else if (gesture == 4) {
            	leftgCount.add(0);
				rightgCount.add(0);
				topgCount.add(0);
				bottomgCount.add(1);
				bottomValue++;
            	System.out.println("This is down gesture");
            	
            	return "down";
            }
            else{
            	return "others";
            }
        }
		return "others";
    }
  
} 